import React from "react";
import "./styles.css"

function Footer() {
    return (
        <div className="footerDiv">
            <h1>What Did You Buidl Today?</h1>
        </div>
    )
}
 export default Footer;
