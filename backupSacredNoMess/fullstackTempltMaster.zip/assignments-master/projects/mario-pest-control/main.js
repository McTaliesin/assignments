document.calculator.addEventListener("submit", function(e){
    e.preventDefault();
    var totalGoombas = document.calculator.goomba.value;
    var totalBobs = document.calculator.bob.value;
    var totalCheeps = document.calculator.cheep.value;
    var result = (parseInt(totalGoombas)*5) + (parseInt(totalBobs)*7) + (parseInt(totalCheeps)*11);
    document.getElementById("invoiceTotal").textContent = "Total invoice is " + result + " coins.";
});
