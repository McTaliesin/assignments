This file contains code that builds a calculator for Mario's pest control business.
