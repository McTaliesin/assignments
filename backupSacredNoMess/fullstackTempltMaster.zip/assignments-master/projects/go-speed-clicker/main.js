var output = localStorage.getItem("Total Clicks");

document.getElementById("buttonToClick").addEventListener("click", myFunction);

function myFunction() {
        output++;
        document.getElementById("totalClicks").innerHTML = "Total Clicks: " + output;
        localStorage.setItem("Total Clicks", output);
}
