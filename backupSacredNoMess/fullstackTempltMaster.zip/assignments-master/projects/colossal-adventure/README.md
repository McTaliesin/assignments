Instructions:

https://coursework.vschool.io/colossal-adventure-console-rpg/
