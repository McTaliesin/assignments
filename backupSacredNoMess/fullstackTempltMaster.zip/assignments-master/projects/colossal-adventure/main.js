//greet with a fun message
//use readline sync to obtain an name and then store it
//make a variable that is empty but able to be set equal to w for walk
//create an empty variable for inventory that new rewards can be stocked in
//make an array that gives an enemy option and 3 other non threatening options
//make an array of objects that contains 3 enemies
//create a readline-sync that gives the options of attacking or running
//if attacking, readline sync an attack power between min and max

var readline = require("readline-sync");
var input = "";
var pouchInventory = [];
var rewards = ["knife", "caffine pill", "$2", "Signed copy of The Art of the Deal"];
var attackChance = ["enemy", "piece of chewing gum", "soda can", "paper bag"];
var enemies = ["Lord Farquad", "Shrek", "Tony the Tiger"];
var damage = 0;
var hp = 0;
var options = ["fight", "run"];
var isAlive = true;

// while (isAlive === true) {
//
// }

function walk(input) {
    var input = readline.question("Press 'w' to continue walking. ");
    var outcome = attackChance[Math.floor(Math.random() * attackChance.length)]
    if (input === "w") {
        if (outcome !== "enemy") {
            console.log("Oh look, another " + outcome + ".");
            walk();
        } else {
            console.log("You've come upon " + enemies[Math.floor(Math.random() * enemies.length)] + "!");
            choice = readline.keyInSelect(options, "Do you fight or run? ");
            if (choice === 0) {
                attack();
            } else {
                coward();
            }
        }
    } else if (input.toLowerCase() === "print") {
        console.log("HP Level: " + hp + "\n" + "Damage Level: " + damage + "\n" + "Pouch Contains: " + pouchInventory);
        walk();
    } else {
        console.log("You must enter either 'w' to walk or 'Print' to print your inventories");
    }
}

function attack(input) {
    var input = readline.question("Between 1 and 10, how much power do you want to use? ");
    var attackPower = (Math.floor(Math.random() * 10))
    if (input > attackPower) {
        console.log("You won the fight!");
        pouchInventory.push(" " + rewards[Math.floor(Math.random() * rewards.length)]);
        hp += 2;
        damage += parseInt(((input - attackPower) - 2));
        console.log("New pouch inventory: " + pouchInventory);
        console.log("HP level: " + hp);
        console.log("Damage level: " + damage);
        walk();
    } else {
        console.log("You lost the battle. Game over");
        var isAlive = false;
    }
}

function coward(input) {
    input = readline.question("Pick a number between 1 and 2 to see if you escape. ");
    var odds = (Math.floor(Math.random() * 2));
    if (input > odds) {
        console.log("You escape!  You lucky son of a gun.");
        damage += parseInt((Math.floor(Math.random() * 10)));
        walk();
    } else {
        console.log("You died.  Game over.");
        var isAlive = false;
    }
}

console.log("Hello!  Welcome to the Colossal Adventure game.")

var name = readline.question("What is your name? ");

console.log(name + ", you have come to a dangerous place.  Watch your back!  And keep moving. ");


walk();
