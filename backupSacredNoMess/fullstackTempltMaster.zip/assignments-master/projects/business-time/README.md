This file contains code practicing building a website of multiple pages that is styled and responsive to window width.
