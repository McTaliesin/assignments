import React from "react";
import "./styles.css"

function Footer() {
    return (
        <div className="footerDiv">
            <h1>This is my footer</h1>
        </div>
    )
}
 export default Footer;
