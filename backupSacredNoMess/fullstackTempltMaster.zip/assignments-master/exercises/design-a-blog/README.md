
This file contains code that renders a basic blog practicing CSS layout and page manipulation.
