This file contains HTML and CSS code that makes a webpage of color blocks that is responsive to a changing window size.
