const express = require("express");
const app = express();
const bodyParser = require("body-parser");
const uuid = require("uuid/v1");

app.use(bodyParser.json())

const teeth = [
    {number: 1, type: "molar - wisdom"},
    {number: 2, type: "molar"},
    {number: 3, type: "molar"},
    {number: 4, type: "molar"},
    {number: 5, type: "canine"}
]

app.get("/teeth", (req, res) => {
    res.send(teeth);
});

app.post("/teeth", (req, res) => {
    req.body.id = uuid();
    teeth.push(req.body);
    return res.send(req.body)
});

app.listen(8000, () => {
    console.log("server is running on port 8000");
});
