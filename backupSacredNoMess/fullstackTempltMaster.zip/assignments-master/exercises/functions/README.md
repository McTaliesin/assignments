This file contains code practicing functions within Javascript.
