// // Instructions
// // Write a function that accepts a string as a parameter.
// If the length of the string is less than or equal to twenty
// characters long, return the string concatenated with itself
// (string + string). If the string is more than twenty characters
// long, return the first half of the string.

// Thought process
// begin function and take input string
// find length of character, determine if it's less than 20
// if so, print the string along with the concat of same string
// if not, slice? the string by string length/2
// var string = "My name is Fitz and I am a cat."

function whatLength(string) {
    if (string.length <= 20) {
        console.log(string.concat(string));
    } else (string.length > 20)
        var newStringLength = string.length * 0.5;
        console.log(string.slice[0, newStringLength]);

}

whatLength("alex is working at his computer this morning.");
