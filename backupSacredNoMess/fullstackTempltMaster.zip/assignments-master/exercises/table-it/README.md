Instructions:

https://coursework.vschool.io/table-it/
