This file contains Javascript code that generates a random password from a selection of letters, numbers, and special characters.
