This file contains code practicing CSS manipulation of an HTML document.
