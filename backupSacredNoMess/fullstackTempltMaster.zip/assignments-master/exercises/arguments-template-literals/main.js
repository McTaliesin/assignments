const dogs = animals.map(animal => animal.type === "dog")

const dogs = 
