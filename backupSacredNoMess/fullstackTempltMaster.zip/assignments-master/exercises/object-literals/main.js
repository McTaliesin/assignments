function collectAnimals() {

}

collectAnimals("dog", "cat", "mouse", "jackolope", "platypus");
// ["dog", "cat", "mouse", "jackolope", "platypus"];


const animalsToArray = (...animals) => animals;

console.log(animalsToArray("dog", "cat", "mouse", "jackolope", "platypus"));
