import React, {Component} from "react";

class App extends Component {
    constructor() {
        super();
        this.state = {
            item: "",
            list: []
        }
        this.handleSubmit = this.handleSubmit.bind(this);
        this.handleChange = this.handleChange.bind(this);
        
    }

    handleSubmit(e){
        e.preventDefault();
        this.setState((prevState) => {
            return {
                item: "",
                list: [...prevState.list, prevState.item]
            }
        });
    }

    handleChange(e){
        this.setState({
            item: e.target.value
        });
    }

    render(){
        return(
            <form onSubmit={this.handleSubmit}>
                <h1>Moms Shopping List</h1>
                <input
                    onChange={this.handleChange}
                    value={this.state.item}
                    name="name"
                />
                <ol>
                    {this.state.list.map(item => <li>{item}</li>)}
                </ol>
                <button>Submit</button>
            </form>
        )
    }
}

export default App;
