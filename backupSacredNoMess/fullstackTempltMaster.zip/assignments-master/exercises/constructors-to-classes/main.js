// function Clown(name, shoeSize, isScary) {
//     this.name = name;
//     this.shoeSize = shoeSize;
//     this.isScary = isScary;
// }
//
// class Clown {
//     constructor(name, shoeSize, isScary) {
//         this.name = name;
//         this.shoeSize = shoeSize;
//         this.isScary = isScary;
//     }
// }


// function HangmanGame(word, guessesUntilLose) {
//     this.word = word;
//     this.guessesUntilLose = guessesUntilLose;
// }
//
// HangmanGame.prototype.wrongGuess = function() {
//     this.guessesUntilLose--;
// }

// class HangmanGame {
//     constructor(word, guessesUntilLose) {
//         this.word = word;
//         this.guessesUntilLose = guessesUntilLose;
//     }
//     wrongGuess() {
//         return this.guessesUntilLose--;;
//     }
// }
//
// const game = new HangmanGame("hello", 5);
// game.wrongGuess();
// console.log(game.guessesUntilLose);


class Media {
    constructor(title, duration) {
        this.title = title;
        this.duration = duration;
        this.isPlaying = false;
    }
    play() {
        return this.isPlaying = true;
    }
    stop() {
        return this.isPlaying = false;
    }
}

class Song extends Media {
    constructor(title, duration, artist) {
        super(title, duration);
        this.artist = artist;
    }
    create() {
        return `${this.title} ${this.duration} ${this.artist}`;
    }
}
const mySong = new Song("The Climb", "3 minutes", "Hannah Montana");
console.log(mySong);
mySong.play();
console.log(mySong.isPlaying);
console.log(mySong.create());
