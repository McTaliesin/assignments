var shopper = {
    name: "Alex Orr",
    age: 26,
    isMale: true,
    groceryCart: ["eggs", "tortillas", "refried beans"],
    description: function() {
        if (this.isMale) {
            var gender = "male";
        } else {
            var gender = "female";
        }
        console.log(this.name + " is " + this.age + " years old " + gender + ". His shopping cart contains " + this.groceryCart[0] + ".");
    }
}

shopper.description()
