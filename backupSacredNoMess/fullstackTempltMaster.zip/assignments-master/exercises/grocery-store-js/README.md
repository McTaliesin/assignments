This file contains code that works with building objects.
