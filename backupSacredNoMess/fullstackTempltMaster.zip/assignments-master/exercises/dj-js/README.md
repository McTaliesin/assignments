This file contains code that creates a webpage that is responsive to actions of the user's mouse.
