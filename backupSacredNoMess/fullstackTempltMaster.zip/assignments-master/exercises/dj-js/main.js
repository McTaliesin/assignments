var box = document.getElementById("box");

box.addEventListener("mouseover", function () {
    document.getElementById("box").style.backgroundColor = "blue";
});

box.addEventListener("mousedown", function () {
    document.getElementById("box").style.backgroundColor = "red";
});

box.addEventListener("mouseup", function () {
    document.getElementById("box").style.backgroundColor = "yellow"
});

box.addEventListener("dblclick", function () {
    document.getElementById("box").style.backgroundColor = "green"
});

box.addEventListener("wheel", function () {
    document.getElementById("box").style.backgroundColor = "orange"
});

document.addEventListener("keydown", function(event) {
    var keyStroke = event.keyCode;

    if (keyStroke === 66) {
        box.style.backgroundColor = "blue";
    } else if (keyStroke === 82) {
        box.style.backgroundColor = "red";
    } else if (keyStroke === 89) {
        box.style.backgroundColor = "yellow";
    } else if (keyStroke === 71) {
        box.style.backgroundColor = "green";
    } else if (keyStroke === 79) {
        box.style.backgroundColor = "orange";
    } else {
        box.style.backgroundColor = "black";
    }
});
