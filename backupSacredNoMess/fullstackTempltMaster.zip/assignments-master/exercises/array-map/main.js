// var doubleNumbers = [2, 5, 100];
//
// var doubleNumbersMap = doubleNumbers.map(function(number){
//     return number * 2;
//     console.log(doubleNumbersMap);
// })
//     console.log(doubleNumbersMap);

// var stringItUP = [2, 5, 100];
//
// var mapForString = stringItUP.map(function(number){
//     return number.toString();
// })
//
// console.log(mapForString);

var peeps = ([
    {
        name: "Angelina Jolie",
        age: 80
    },
    {
        name: "Eric Jones",
        age: 2
    },
    {
        name: "Paris Hilton",
        age: 5
    },
    {
        name: "Kayne West",
        age: 16
    },
    {
        name: "Bob Ziroll",
        age: 100
    }
])

// var nameOnly = peeps.map(function(people){
//     return people.name.split();
// })
// console.log(nameOnly);

// var ofAge = peeps.map(function(person){
//     if (person.age >= 18) {
//         console.log(person.name + " can go see the Matrix!");
//     } else {
//         console.log(person.name + " is not old enough to go see the Matrix!");
//     }
// })

var toHtml = peeps.map(function(people){
    console.log("<h1>" + people.name + "<h1>");
    console.log("<h2>" + people.age + "<h2>");
})
