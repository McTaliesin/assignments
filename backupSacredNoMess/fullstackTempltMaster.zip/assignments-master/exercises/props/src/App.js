import React from "react";
import Template from "./Template.js";

function App() {
    return (
        <div>
            <Template color="red" title="The Art of the Deal" sub="MAGA" price="$0.99" />
            <Template color="blue" title="The Definitive Book of Body Language" sub="Learn Body language" price="$1.99" />
            <Template color="gray" title="Outliers" sub="Stats stuff" price="$7.99" />
            <Template color="pink" title="Jesus Interrupted" sub="required reading" price="$4.99" />
            <Template color="violet" title="Misquoting Jesus" sub="Sequal to required reading" price="$8" />
            <Template color="orange" title="Trump: Never Give Up" sub="yeah, don't give up" price="$4" />
            <Template color="maroon" title="The Everything Store" sub="Jeff Bezos!!!" price="$3.86" />
            <Template color="yellow" title="Shoe Dog" sub="The Saga of High Profit Margins" price="$3.67" />
            <Template color="gold" title="Getting to Yes" sub="Sell them" price="$2.48" />
            <Template color="green" title="Stock Options" sub="Stock options" price="$9.99" />
        </div>
    )
}

export default App
