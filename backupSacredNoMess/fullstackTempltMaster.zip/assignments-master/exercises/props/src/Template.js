import React from "react";

function Template(props) {
    const styles = {
        backgroundColor: props.color
    }

    return (
        <h1 style={styles}> Book Title: {props.title} | Subtitle: {props.sub} | Price: {props.price} </h1>
    )
}

export default Template
