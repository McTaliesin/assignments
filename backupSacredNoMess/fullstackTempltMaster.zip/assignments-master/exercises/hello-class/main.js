function hello(name) {
  console.log("Hello, class!  My name is " + name);
}

hello("Alex");
