This file contains code practicing CSS manipulation.
