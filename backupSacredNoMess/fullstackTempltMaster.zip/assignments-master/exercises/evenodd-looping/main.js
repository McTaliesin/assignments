for (i = 0; i <= 100; i++) {
    if (i%2 == 0) {
        console.log("even");
    } else {
        console.log("odd");
    }
}
