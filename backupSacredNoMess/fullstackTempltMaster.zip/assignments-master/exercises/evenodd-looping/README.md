This file contains code that loops through numbers and determines if they are even or odd.
