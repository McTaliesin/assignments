This website contains code that builds a website displaying "Hello World" and a ordered list of jokes.
