import React, {Component} from "react";

class App extends Component {
    constructor() {
        super();
        this.state ={
            count: 0
        };
        this.addOne = this.addOne.bind(this);
        this.subOne = this.subOne.bind(this);
        this.multiplyByTwo = this.multiplyByTwo.bind(this);
        this.divideByTwo = this.divideByTwo.bind(this);
    }

    divideByTwo() {
        this.setState(prevState => {
            return {
                count: Math.floor(prevState.count / 2)
            }
        })
    }

    subOne() {
        this.setState(prevState => {
            return {
                count: prevState.count - 1
            }
        });
    }

    addOne() {
        this.setState(prevState => {
            return {
                count: prevState.count + 1
            }
        });
    }

    multiplyByTwo() {
        this.setState(prevState => {
            return {
                count: prevState.count * 2
            }
        });
    }

    render() {
    return (
        <div>
            <button onClick={this.divideByTwo}>/2</button>
            <button onClick={this.subOne}>-</button>
            <h1>{this.state.count}</h1>
            <button onClick={this.addOne}>+</button>
            <button onClick={this.multiplyByTwo}>*2</button>
        </div>
    )
    }
}

export default App;
