import React from "react";

function Footer() {
    return (
        <p className="latin">Copyright 2018 by Orr Acquisitions</p>
    )
}

export default Footer;
