import React from "react";
import Nav from "./Nav.js";
import Info from "./Info.js";
import Pns from "./Pns.js";
import Footer from "./Footer.js";
import "./Appstyles.css";


function App() {
    return (
        <body>
        <div className="navigation">
        <Nav />
        </div>
        <div className="information">
        <Info />
        </div>
        <div className="productsServices"><Pns /></div>
        <div className="gallery">
        <img className="imgs" src="http://media.equityapartments.com/images/q_50/f_auto/fl_lossy/4011-28/moda-apartments-exterior" />
        <img className="imgs" src="https://images1.apartments.com/i2/bmmuQQ89igEy3-NRYSb-gvrbkZfsjAAXanCkPhRglcU/111/one-light-luxury-apartments-kansas-city-mo-building-photo.jpg" />
        </div>
        <div className="footer"><Footer /></div>
        </body>

    )
};

export default App;
