import React from "react";

function Pns() {
    return (
        <ul className="latin">
            <li className="item">New construction</li>
            <li className="item">Remodel</li>
            <li className="item">Property management</li>
            <li className="item">Portfolio growth</li>
        </ul>
    )
};

export default Pns;
