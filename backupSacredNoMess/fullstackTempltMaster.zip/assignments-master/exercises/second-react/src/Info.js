import React from "react";

function Info() {
    return (
        <p className="latin">Lorem ipsum dolor sit amet, ne duo graeco dolores platonem, an tation labitur partiendo nec. Te quo vide ullum. Eu sed primis doctus fabellas, an perfecto recusabo sit. Sed te vero liber platonem. Vivendum lobortis similique pri et. Saepe legendos recteque at usu, his ut unum explicari.

Debet adipiscing consequuntur eos te, augue volutpat recteque an his. Ea noster delenit cum. Viris nostrud ad per, per simul nonumes ut. At vix facer oblique. Ea sanctus commune invenire sed, sed id utamur scripta mediocrem. Ne eos veniam interesset theophrastus, graeco causae officiis id sit, minim veniam nonumes sed ex.

Quo vero dolor apeirian id, eu sea ullum prompta. Has et dicam detracto tincidunt, sit lorem nonumes intellegebat ne. No eros illud eam, ut mollis atomorum vel. Partem graeco sit at. Iuvaret equidem duo ea, duo no alii nobis disputando. Ad vidisse legimus copiosae eum, eu commune oporteat eum, alii labitur legendos duo id.

Ut accusata constituto eum. Est zril insolens no, periculis disputationi no mel. Nec sale iisque constituto id, at eum putant iriure vivendo. Sea no case paulo aliquid. Iudico labores electram eos in, cu stet eius probatus eam, at mea persius aliquid delectus.

Vel sint ignota pertinax ut, his habeo idque fierent ex. Natum placerat ad per, eum aperiri nusquam abhorreant ea. At quando tempor oportere per, his ex munere blandit accusamus. Nullam reformidans an nec, putent feugiat singulis ea eum. In falli inimicus principes eum, an tempor mentitum sea.

Quis iusto honestatis sed no, no qui facer graece splendide. Per in nominati conceptam definiebas, at sumo dissentiet mei, mea vocent vivendum ex. Ut enim corpora qui, vis cu minim soluta graeci, vix in tollit patrioque. Mel in mundi accusam, vel eu appetere evertitur mediocritatem, vel an idque temporibus scriptorem.

Duo id essent everti minimum, qui an wisi voluptua. In mei oratio epicurei inciderint. An oportere corrumpit quo. Duis discere vis cu, mei putant timeam ei. Malorum graecis id sit.

Mel ut commune fabellas, per ex elit magna epicurei. Ad per simul tation. Dicam quidam explicari an vel. Gubergren democritum per no. Ut has alii inani zril. Ad veritus quaestio mea.

Quis duis qui eu, eos ut augue officiis recteque. Doming gubergren elaboraret te qui. Sumo utinam te pri, quo virtute aliquando complectitur at. Eam molestie tincidunt ei.

Sea officiis invidunt cu. Volumus explicari urbanitas ei vis, tantas euismod euripidis sit at. Id vim agam possim, no vim inimicus concludaturque, debet audire id mei. Alii enim eripuit ut mel, in vis nulla scaevola constituto, elit causae splendide no sed. In pri malorum officiis, atqui audire ullamcorper te ius. Eum ne quod copiosae invidunt. Eu ius quis evertitur percipitur.</p>
    )
};

export default Info;
