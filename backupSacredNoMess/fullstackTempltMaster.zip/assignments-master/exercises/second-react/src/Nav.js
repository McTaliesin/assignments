import React from "react";

function Nav(){
    const styles = {
        fontFamily: "Montserrat",
        backgroundColor: "#7F29B2",
        fontSize: "20px",
        listStyleType: "none",
        justifyContent: "auto",
        display: "flex",
        justifyContent: "space-around",
        verticalAlign: "middle"
    }
    
    const liStyles = {
        // display:"inline",
        // marginLeft: "20px",
        // marginRight:"20px"
    }

    return (
        <ul style={styles}>
        <li style={liStyles}>About</li>
        <li style={liStyles}>Products</li>
        <li style={liStyles}>Contact</li>
        </ul>
    )
};

export default Nav;
