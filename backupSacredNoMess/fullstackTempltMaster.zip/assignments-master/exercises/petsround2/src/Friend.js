import React from "react";
import Pet from "./Pet";
import FriendsList from "./FriendList";

function Friend(props) {
    const mappedPets = props.pets.map(function(pet) {
        return <Pet name={pet.name} breed={pet.breed} />;
    })
    return (
        <div>
            <h1>{props.name}</h1>
            <p>{props.age}</p>
            <div>{mappedPets}</div>
        </div>
    )
}

export default Friend;
