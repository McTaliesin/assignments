import React from "react";
import FriendList from "./FriendList";

function App() {
    return (
        <div>
            <FriendList />
        </div>
    )
}

export default App;
