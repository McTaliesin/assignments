import React from "react";
import Friend from "./Friend";

function Pet(props) {
    return (
        <div>
            <p>Name: {props.name}</p>
            <p>Breed: {props.breed}</p>
        </div>
    )
}

export default Pet;
