var students = ["John", "Jacob", "Jingle", "heimer", "Smith"];

for (var i = 0; i < students.length; i++) {
    console.log(students[i]);
}
