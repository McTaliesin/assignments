var express = require("express")
var app = express();
var bodyParser = require("body-parser");

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: false}));

var ingredients = [
    {
        "id": "232kAk",
        "text": "Eggs"
    },
    {
        "id": "adsfadsf",
        "text": "Milk"
    },
    {
        "id": "2351234",
        "text": "Bacon"
    },
    {
        "id": "wrw62345",
        "text": "Frog Legs"
    }
];


app.get("/ingredients", function(req, res) {
    res.send(ingredients)
})

app.post("/ingredients", function(req, res) {
    var ingredient = req.body;
    ingredients.push(ingredient);
    res.send(ingredients);
})

app.put("/ingredients/:ingredientId", function(req, res) {
    var ingredientId = req.params.ingredientId
    var newText = req.body.text

    for (var i = 0; i < ingredients.length; i++) {
        var ing = ingredients[i];
        if (ing.id === req.params.ingredientId) {
            ingredients[i].text = newText;
            break;
        }
    }

    res.send(ingredients);
})

app.delete("/ingredients/:ingredientId", function(req, res) {
    var ingredientId = req.params.ingredientId;

    for (var i = 0; i < ingredients.length; i++) {
        var ing = ingredients[i];
        if (ing.id === req.params.ingredientId) {
            ingredients.splice(i, 1);
            break;
        }
    }
    res.send(ingredients);
})

app.listen(3000, function() {
    console.log("First api is running on port 3000");
})
