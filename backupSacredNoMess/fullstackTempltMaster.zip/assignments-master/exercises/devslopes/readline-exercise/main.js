var readline = require("readline-sync");

var num1 = readline.question("Please enter a number")

var num2 = readline.question("please enter another number");

var op = readline.question("enter an operator");

var output;

function app(num1, num2) {
  if (op === "+") {
      output = parseInt(num1) + parseInt(num2);
  } else if (op === "-") {
      output = num1 - num2;
  } else if (op === "*") {
      output = num1*num2;
  } else if (op === "/") {
      output = num1/num2;
  } else {
      console.log("enter a real operator");
  }
  return output;
}

app(num1, num2)

console.log(output);
