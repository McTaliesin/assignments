This file contains code that practices string methods.
