var fitzAttributes = "Fitz is a lucky cat who likes to bite to say hello.";
var mauriceAttributes = "Maurice is a kind, opinionated cat who just likes to play.";

connected = fitzAttributes.concat(" " + mauriceAttributes);

console.log(connected);

abc = connected.lastIndexOf("p");

console.log(abc);

var lastWord = connected.slice(105);
console.log(connected);

console.log(connected.match(/ucky/));

console.log(fitzAttributes.replace("Fitz", "Alex"));

newString = fitzAttributes.slice(10);
console.log(newString);

everyChar = fitzAttributes.split("");
console.log(everyChar);

upperCase = fitzAttributes.toUpperCase();
console.log(upperCase);

lowerCase = fitzAttributes.toLowerCase();
console.log(lowerCase);

subtracted = fitzAttributes.substr(1, 6);
console.log(subtracted);
