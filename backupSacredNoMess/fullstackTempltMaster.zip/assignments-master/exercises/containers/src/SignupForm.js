import React, {Component} from "react";

class SignupForm extends Component{
    constructor() {
        super();
        this.state = {
            firstName: "",
            lastName: "",
            email: "",
            password: "",
            passwordConfirm: ""
        }
    }

    render() {
        return (
            <h1>hey</h1>
        )
    }
}


export default SignupForm;
