import React from "react";

const Footer = () => {
    return (
        <footer>This is where the footer goes</footer>
    )
}



export default Footer;
