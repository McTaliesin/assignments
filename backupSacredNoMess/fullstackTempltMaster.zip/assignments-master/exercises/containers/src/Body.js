import React from "react";
import SignupForm from "./SignupForm";

const Body = () => {
    return (
        <main>
            <SignupForm />
        </main>
    )
}



export default Body;
