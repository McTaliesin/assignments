import React from "react";

const App = () => {
    return (
        <h1>hiya!</h1>
    )
}



export default App;
