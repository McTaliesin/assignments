import React from "react";

const Header = () => {
    return (
        <header>This is where the header goes</header>
    )
}



export default Header;
