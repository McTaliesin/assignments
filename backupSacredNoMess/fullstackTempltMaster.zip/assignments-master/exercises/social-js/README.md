This file contains code practicing objects, arrays, and methods.
