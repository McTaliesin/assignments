var alexOrr = {
    firstName: "Alex",
    lastName: "Orr",
    favoriteFoods: ["breakfast burriots", "Chipotle", "hamburgers"],
    occupation: ["student", "real estate investor", "auctioneer"],
    catDescription: [
        {
            fullName: "Fitzgerald",
            nickName: "Fitz",
            gender: "male",
            isRescue: true
        }
    ],
    friendsWith: [
        {
            firstName: "Bryan",
            lastName: "Kelsey",
            occupation: "teacher",
            age: 29,
            hobbies: ["writing scripts", "coaching basketball"],
            saysName: console.log("I pronouce my name "+ this.firstName + this.lastName)
        }
    ],
    friendsWith: [
        {
            firstName: "Courtney",
            lastName: "Orr",
            favoriteFoods: ["carrotts", "Chick-fil-a", "lettuce"],
            friendsWith: [
                {
                    firstName: "Lester",
                    lastName: "Orr",
                    occupation: "retired",
                    age: 69,
                    hobbies: ["plastic moulding", "managing properties"]
                }
            ]
        }
    ],
    friendsWith: [
        {
            firstName: "Gay",
            lastName: "Orr",
            favoriteFoods: ["hummus", "tea", "grapes"],
            friendsWith: [
                {
                    firstName: "Beverly",
                    lastName: "Greene",
                    occupation: "heathcare",
                    age: 60,
                    hobbies: ["working for CDC", "spending time with grandchildren"]
        }
            ]
        }
    ]
};

console.log(alexOrr);

alexOrr.computerType = "Macbook Pro"
alexOrr.hairColor = "blonde"
alexOrr.occupation.push("property manager", "caretaker");
