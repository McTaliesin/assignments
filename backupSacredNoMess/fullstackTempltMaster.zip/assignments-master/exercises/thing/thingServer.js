const express = require("express");
const app = express();
const uuid = require("uuid/v4");
const bodyParser = require("body-parser");
app.use(bodyParser.json());

const fruits = [
    {
        type: "banana",
        brand: "Banana Republic",
        price: 2,
        id: ""
    },
    {
        type: "banana",
        brand: "Bapublic",
        price: 4,
        id: ""
    },
    {
        type: "banana",
        brand: "DDDanaic",
        price: 3,
        id: ""
    },
    {
        type: "apple",
        brand: "Mac",
        price: 2,
        id: ""
    }
]

app.get("/thing", (req, res) => {
    if (req.query.type) {
        res.send(fruits.filter(fruit => fruit.type === req.query.type))
    } else {
        res.send(fruits);
    }
});

app.get("/thing?type=banana", (req, res) => {
    res.send(fruits.filter(function(fruit) {
        fruit.type === "banana"
    }));
});

app.post("/thing", (req, res) => {
    req.body.id = uuid();
    fruits.push(req.body);
    return res.send(fruits);
});

app.listen(9000, () => {
    console.log("The thing server is running on host 9000");
});
