var obj = {
    name: "Billy",
    age: 45,
    cars: [
        {
            year: 2002,
            make: "Toyota",
            model: "Camry"
        },
        {
            year: 2018,
            make: "Tesla",
            model: "Roadster"
        }
    ]
}

localStorage.user = JSON.stringify(obj);

var user = JSON.parse(localStorage.user);
