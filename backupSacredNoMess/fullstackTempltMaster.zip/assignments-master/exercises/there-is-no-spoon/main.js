var book = {
    color: "green",
    cover: "hard",
    title: "The Art of the Pitch",
    write: function() {
        console.log("The book is called " + this.title + ".");
    }
}

var headphones = {
    color: "black",
    numberOfSpeakers: 2,
    cordLength: "3 feet",
    isBlack: true,
    write: function() {
        console.log( "The headphones are " + this.color + ".");
    }
}

var catCondo = {
    color: "tan",
    material: "carpet",
    height: "4 feet",
    write: function() {
        console.log("The cat condo is " + this.color + ".");
    }
}

var modernChair = {
    color: "black",
    attributes: ["leather", "newspaper holder", "recliner"],
    hasFootStool: true,
    write: function() {
        console.log("The modern chair has " + this.attributes[0] + "upholstry.");
    }
}

var macBookAir = {
    color: "silver",
    ssdSize: 128,
    isOn: true,
    write: function() {
        console.log("My Macbook Air has a " + ssdSize + " GB SSD.");
    }
}

var saltLamp = {
    size: "small",
    location: "under the TV.",
    ageYrs: 2,
    write: function() {
        console.log("My salt lamp is located " + this.location);
    }
}

var coffeeTable = {
    color: "white.",
    hasSignatures: true,
    containsNames: ["Greg", "Emily", "Carson"],
    write: function() {
        console.log("The coffee table is " + this.color);
    }
}

var couch = {
    material: "leather",
    seatsPersons: 2,
    style: "loveseat",
    write: function() {
        console.log("My couch is technically called a " + this.style + ".");
    }
}

var desk = {
    shape: "L",
    top: "glass",
    isCluttered: true,
    write: function() {
        console.log("My desktop is in the shape of an " + this.shape + ".");
    }
}

var wallet = {
    condition: "used",
    isHoldingCash: true,
    color: "black",
    write: function() {
        console.log("My wallet is in " + this.condition + " condition.");
    }
}
