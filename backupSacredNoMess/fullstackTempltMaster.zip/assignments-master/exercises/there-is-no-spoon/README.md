This file contains code practicing building objects.
