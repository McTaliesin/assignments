This file contains Javascript code that practices manipulating a string in various ways.
