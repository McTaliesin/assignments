var readlineSync = require("readline-sync");

var firstName = (readlineSync.question("May I have your name? ")).toUpperCase();
var lastName = (readlineSync.question("What is your last name? ")).toUpperCase();
var firstLength = firstName.length;

console.log("Good to meet you " + firstName + " " + "!  Your first name contains " + firstLength + " letters.\n");

console.log("Your full name is also " + firstName.concat(" " + lastName) + ".\n");


var longMessage = readlineSync.question("In a minimum of 20 characters, tell me your about your favorite food and why it is so. \n");

if (longMessage.length < 20) {
    console.log("Your sentence is too short!\n")
}

var halfLm = longMessage.substr(0,(longMessage.length / 2));

console.log("Did you know that half of the string your just entered is " + halfLm + "?\n");

var startingPoint = readlineSync.question("Given the string you typed, at what index would you like to start print of the string all the way to the string's end? \n");

console.log("Here you go: " + longMessage.substr(startingPoint, longMessage.length));
