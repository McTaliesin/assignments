import React from "react";
import ReactDOM from "react-dom";
import HelloWorld from "./HelloWorld.js"

ReactDOM.render(
    <HelloWorld />,
    document.getElementById("root")
);
