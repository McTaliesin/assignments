This file contains code practicing looping through an array.
