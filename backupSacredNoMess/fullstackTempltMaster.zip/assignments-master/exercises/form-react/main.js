//practice

import React, {Component} from "react";

class Form extends Component {
    constructor() {
        super()
        this.state = {
            name: "",
            age: ""
        }
        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
    }

    handleSubmit(e){
        e.preventDefault();
        this.setState({
            name: "".
            age: ""
        });

    handleChange(e){
        this.setState({[e.target.name]: e.target.value});
    }

    render(){
        return(
            <form onSubmit={this.handleSubmit}>
            Enter Your Name:
            <input
                onChange={this.handleChange}
                value={this.state.name}
                name="name"
            />
            Enter Your Age:
            <input
                onChange={this.handleChange}
                value={this.state.age}
                name="age"
                value="number"
                />
                </button>
                </form>
        )
    }
    }
}




// import React, {Component} from "react";
//
// class Form extends Component {
//     constructor(){
//         super()
//         this.state = {
//             name: "",
//             age: ""
//         }
//
//         this.handleChange = this.handleChange.bind(this);
//         this.handleSubmit = this.handleSubmit.bind(this);
//     }
//
//     handleSubmit(e){
//         e.preventDefault();
//         this.setState({
//             name: "",
//             age: ""
//         });
//     }
//
//     handleChange(e){
//         this.setState({[e.target.name]: e.target.value});
//     }
//
//     render(){
//         return (
//             <form onSubmit={this.handleSubmit}>
//                 Enter your name:
//                 <input
//                     onChange={this.handleChange}
//                     value={this.state.name}
//                     name="name"
//                 />
//                 Ender your age:
//                 <input
//                     onChange={this.handleChange}
//                     value={this.state.age}
//                     name="age"
//                     type="number"
//                 />
//                 <button>submit</button>
//             </form>
//         )
//     }
// }
//
// export default Form;
