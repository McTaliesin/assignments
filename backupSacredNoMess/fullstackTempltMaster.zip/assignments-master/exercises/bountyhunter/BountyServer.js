const express = require("express");
const app = express();
const uuid = require("uuid/v4");
const bodyParser = require("body-parser");
app.use(bodyParser.json());

const bounties = [
    {
        firstName: "Alex",
        lastName: "Orr",
        living: true,
        bountyAmount: 500,
        type: "Jedi",
        id: ""
    }
]

app.get("/bounty", (req, res) => {
    res.send(bounties);
});

app.post("/bounty", (req, res) => {
    req.body.id = uuid();
    bounties.push(req.body);
    return res.send(req.body);
})

app.put("/bounty/:id", (req, res) => {
    res.send(bounties.req.params)
})


app.listen(5000, () => {
    console.log("The Bounty Server is running");
});
