This file contains code building a mock Onion article about the CIA.
