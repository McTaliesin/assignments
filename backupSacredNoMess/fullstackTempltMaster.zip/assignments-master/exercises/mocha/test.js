const firstLastOver17 = require("./main").firstLastOver17;
const sum = require("./main").sum;

const chai = require("chai");
const assert = chai.assert;

const firstLastOver17 = require("./main");



const people = [
    {
        firstName: "Jerry",
        lastName: "Gergich",
        age: 52
    },
    {
        firstName: "Leslie",
        lastName: "Knope",
        age: 40
    },
    {
        firstName: "Tommy",
        lastName: "Haverford",
        age: 10
    },
    {
        firstName: "Ronny",
        lastName: "Swanson",
        age: 7
    }
]

console.log(firstLastOver17(people));

describe("Higher order functions", () => {
    it("should subtract an array of numbers", () => {
        assert.equal(dif([1, 2]), -1);
        assert.equal(dif(["-1", "-1"]), 0);
    });
    it("should return a number", () => {
        assert.typeOf(sum(["1", "2"]), "number")
    });

    it("should return the difference of numbers in an array", () => {
        assert.equal(difference([1, 2], -1)
    })
});
