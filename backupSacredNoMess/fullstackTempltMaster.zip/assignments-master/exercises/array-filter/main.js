var problemOneArray = [3, 6, 8, 2];

var strings = ["dog", "wolf", "by", "family", "eaten", "camping"];

var peopleWhoBelongToTheIlluminati = ([
  {
    name: "Angelina Jolie",
    member: true
  },{
    name: "Eric Jones",
    member: false
  },{
    name: "Paris Hilton",
    member: true
  },{
    name: "Kayne West",
    member: false
  },{
    name: "Bob Ziroll",
    member: true
  }
])

var movieGoers = ([
  {
    name: "Angelina Jolie",
    age: 80
  },{
    name: "Eric Jones",
    age: 2
  },{
    name: "Paris Hilton",
    age: 5
  },{
    name: "Kayne West",
    age: 16
  },{
    name: "Bob Ziroll",
    age: 100
  }
])

// var noneLessThanFive = problemOneArray.filter(function(number) {
//     return number > 5;
// })
//
// console.log(noneLessThanFive);

// var noneOdd = problemOneArray.filter(function(number) {
//     return (number % 2 === 0);
// })
// console.log(noneOdd);

// var noneLessThanFiveChar = strings.filter(function(string) {
//     return string.length <= 5;
// })
// console.log(noneLessThanFiveChar);
//
// var members = peopleWhoBelongToTheIlluminati.filter(function(member) {
//     return member.member === true;
// })
// console.log(members);

var notOldEnough = movieGoers.filter(function(person) {
    return person.age <= 18;
})
console.log(notOldEnough);
