import React from "react";

function TodoForm(props){
    return (
        <div>
            <form onSubmit={props.handleSubmit} className="todoForm">
                <label>
                <input
                    type="text"
                    onChange={props.handleChange}
                    value={props.values.title}
                    placeholder="Title"
                    name="title"
                />
                </label>
                <label>
                <input
                    type="text"
                    onChange={props.handleChange}
                    value={props.values.description}
                    placeholder="Description"
                    name="description"
                />
                </label><label>
                <input
                    type="text"
                    onChange={props.handleChange}
                    value={props.values.price}
                    placeholder="Price"
                    name="price"
                />
                </label>
                <label>
                <input
                    type="text"
                    onChange={props.handleChange}
                    value={props.values.imgUrl}
                    placeholder="imgUrl"
                    name="imgUrl"
                />
                </label>
                <button>Submit</button>
            </form>
        </div>
    )
}

export default TodoForm;
