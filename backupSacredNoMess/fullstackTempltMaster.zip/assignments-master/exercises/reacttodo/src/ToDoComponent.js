import React from "react";

function ToDoComponent(props){
    return (
        <div className="todoContainer">
            <div className="todoTitle">
                Title: {props.title}
            </div>
            <div>
                Description: {props.description}
            </div>
            <div>
                Price: {props.price}
            </div>
            <div>
                <img src={props.imgUrl} className="images"/>
            </div>
            <button onClick={() => {props.handleDelete(props.id)}}>Delete</button>
        </div>
    )
}

export default ToDoComponent;
