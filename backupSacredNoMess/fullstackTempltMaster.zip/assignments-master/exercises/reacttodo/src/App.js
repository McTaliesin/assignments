import React from "react";
import axios from "axios";
import ToDoComponent from "./ToDoComponent";
import TodoForm from "./TodoForm";

const todoUrl = 'https://api.vschool.io/alexorr/todo/'

class App extends React.Component {
    constructor(){
        super();
        this.state = {
            todos: [],
            inputs: {
                title: "",
                value: "",
                description: "",
                price: "",
                imgUrl: ""
            } 
        }
        
        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
        this.handleDelete = this.handleDelete.bind(this);
    }
    componentDidMount(){
        axios.get(todoUrl).then(response => {
            //console.log(response);
            this.setState({
                todos: response.data
            })
        })
    }
    
    handleChange(e){
        e.persist();
        this.setState(prevState => {
            return {
                ...prevState,
                [e.target.name]: e.target.value
            }
        })
        console.log(this.state)
    }
    
    handleDelete(id) {
        axios.delete(todoUrl + id).then(response => {
            this.setState(prevState => {
                return {
                    todos: prevState.todos.filter(todo => {
                        return todo._id !== id;
                    })
                }
            })
        })
    }
    
    handleSubmit(e){
        e.preventDefault();
        // let newTodo = {
        //     title: this.state.title,
        //     description: this.state.description,
        //     price: this.state.price,
        //     imgUrl: this.state.imgUrl
        // }
        axios.post(todoUrl, this.state).then(response => {
            this.setState(prevState => {
                return {
                    todos: [response.data, ...prevState.todos],
                    title: "",
                    value: "",
                    description: "",
                    price: "",
                    imgUrl: "" 
                }   
            })
        })
    }
    
    render() {
        const mappedToDos = this.state.todos.map((todo, index) => {
            return (
                <ToDoComponent 
                    title={todo.title} 
                    description={todo.description} 
                    imgUrl={todo.imgUrl} 
                    price={todo.price}
                    id={todo._id}
                    key={todo + index}
                    handleDelete={this.handleDelete}
                />
            )
        })
        
    return (
        <div className="appContainer">
        <div className="todoFormContainer">
        <TodoForm values={this.state} handleChange={this.handleChange} handleSubmit={this.handleSubmit}/>
        </div>
        <div className="mappedToDosContainer">
        {mappedToDos}
        </div>
        </div>
    )
    }
}

export default App;
