const express = require("express");
const characterRoutes = express.Router();
const Character = require("../models/characters")

characterRoutes.get("/", (req, res) => {
    Character.find((err, characters) => {
        if (err) return res.status(500).send(err);
        return res.send(characters);
    })
})

characterRoutes.get("/:id", (req, res) => {

})

characterRoutes.post("/", (req, res) => {

})

characterRoutes.put("/:id", (req, res) => {

})

characterRoutes.delete("/:id", (req, res) => {

})



module.exports = characterRoutes;
