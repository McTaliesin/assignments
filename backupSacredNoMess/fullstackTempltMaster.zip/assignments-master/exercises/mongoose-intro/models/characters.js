const mongoose = require("mongoose");
const Schema = mongoose.Schema;

// const {Schema, model} = require("mongoose");

const testSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true
    },
    rank: String,
    ssn: String,
    hairColor: String,
    height: Number,
    characteristics: {
        type: String,
        minlength: 1,
        maxlength: 100,
        enum: ["Funny", "Smart", "Handsome", "Ugly", "Mean", "Dumb"]
    }
});

module.exports = mongoose.model("Characters", testSchema);
