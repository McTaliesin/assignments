const express = require("express");
const app = express();
const port = process.env.PORT || 7000;
const bodyParser = require("body-parser");
const morgan = require("morgan");
const mongoose = require("mongoose");

app.use("/characters", require("./routes/character"))
mongoose.connect("mongodb://localhost/mario-kart", (err) =>{
    if (err) {
        throw err;
    }
    console.log("connected to the database");
});
app.use(bodyParser.json());
app.use(morgan("dev"));



const charactersSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true
    },
    rank: String,
    ssn: String,
    hairColor: String,
    height: Number,
    characteristics: {
        type: String,
        minlength: 1,
        maxlength: 100,
        enum: ["Funny", "Smart", "Handsome", "Ugly", "Mean", "Dumb"]
    }
});

const Characters = mongoose.model("Characters", charactersSchema);

app.listen(port, () => {
    console.log(`server is running on port ${port}`);
})
