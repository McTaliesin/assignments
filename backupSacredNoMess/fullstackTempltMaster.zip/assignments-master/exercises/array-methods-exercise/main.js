var fruit = ["banana", "apple", "orange", "watermelon"];
var vegetables = ["carrot", "tomato", "pepper", "lettuce"];

console.log(vegetables.pop());
console.log(vegetables);

console.log(fruit.shift());
console.log(fruit);

var index = fruit.indexOf("orange");
console.log(index);

fruit.push(index);
console.log(fruit);

console.log(vegetables.length);
var vegLength = vegetables.length;

console.log(vegLength);

vegetables.push(vegLength);
console.log(vegetables);

var food = fruit.concat(vegetables);
console.log(food);

food.splice(4, 2);
console.log(food);

food.reverse();
console.log(food);
