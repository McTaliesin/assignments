This file contains code that manipulates arrays via Javascript.
