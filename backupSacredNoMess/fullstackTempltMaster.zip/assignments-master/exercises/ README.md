This file contains the daily exercises from my time at V School.
