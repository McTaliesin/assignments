This file contains code practicing loops and Javascript.
