var fruit = ["banana", "orange", "apple", "kiwi", "pear", "peach"];

var everyOther = []

for (i = 0; i < fruit.length; i = i + 2) {
    everyOther.push(fruit[i]);
}
 console.log(everyOther)
