const express = require("express");
const placesRoutes = express.Router();

placesRoutes.get("/", (req, res) => {

});

placesRoutes.get("/:id", (req, res) => {

});

placesRoutes.post("/", (req, res) => {

});

placesRoutes.put("/:id", (req, res) => {

});

placesRoutes.delete("/:id", (req, res) => {

});

module.exports = placesRoutes;
