const express = require("express");
const nameRoutes = express.Router();

nameRoutes.get("/", (req, res) => {
    res.send(`${req.method} request to ${req.baseUrl + req.url}`);
});

nameRoutes.get("/:id", (req, res) => {

});

nameRoutes.post("/", (req, res) => {

});

nameRoutes.put("/:id", (req, res) => {

});

nameRoutes.delete("/:id", (req, res) => {

});


module.exports = nameRoutes;
