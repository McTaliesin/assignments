const express = require("express");
const app = express();
const uuid = require("uuid/v4");
const bodyParser = require("body-parser");
const morgan = require("morgan");
const nameRoutes = require("./routes/names");
const placesRoutes = require("./routes/places");
app.use(bodyParser.json());
app.use((req, res, next) => {
    console.log("hey I'm a middlewear");
    next();
})

app.use((req, res, next) => {
    console.log("hey I the second middlewear");
    next();
})

app.use("/names", nameRoutes);
app.use("/places", placesRoutes);


app.listen(9001, () => {
    console.log("the server is running on over 9000!!!!!!!!!");
})
