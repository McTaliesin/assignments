// take a string and loop through it, looking at each letter and determining if it is upper or lower case.
// if they

alteredString = "";

function antiCaps(string) {
    for (i = 0; i < string.length; i++) {
        if (string[i] === string[i].toLowerCase()) {
            alteredString += string[i].toUpperCase();
        } else if (string[i] === string[i].toUpperCase()) {
            alteredString += string[i].toLowerCase();
        } else {
            alteredString += string[i];
        }
    }
    console.log(alteredString);
}

antiCaps("Hello");
