The instructions for this file can be found at:

https://coursework.vschool.io/anti-caps/
