import React, {Component} from "react";

class App extends Component {
    constructor(){
        super()
        this.state = {
            name: ""
        }
        this.arr = [];
        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
    }

    handleSubmit(e){
        e.preventDefault();
        this.setState({
            name: ""
        });
        this.arr.push(this.state.name);
        console.log(this.arr);
    }

    handleChange(e){
        this.setState({[e.target.name]: e.target.value});
    }

    render(){
        return (
            <form onSubmit={this.handleSubmit}>
                <h1>{this.state.name}</h1>
                <ul>
                    {this.arr.map(item => <li>{item}</li>)}
                </ul>
                Enter Your Name:
                <input
                    onChange={this.handleChange}
                    value={this.state.name}
                    name="name"
                />
                <button>Submit</button>
            </form>
        )
    }
}
export default App;
