import React from "react";

function Template(props) {
    var noDollar = props.price.slice(1);
    var strToNum = parseInt(noDollar);
    var priceRange;
    var styles;
    if(strToNum < 500 && strToNum > 0) {
        priceRange = "$";
    } else if (strToNum < 1000 && strToNum > 500) {
        priceRange = "$$";
    } else {
        priceRange = "$$$";
    }

    if(props.timeToGo === "Spring") {
        styles = {
            backgroundColor: "yellow",
        }
    } else if(props.timeToGo === "Summer") {
        styles = {
            backgroundColor: "red",
        }
    } else if(props.timeToGo === "Fall") {
        styles = {
            backgroundColor: "orange",
        }
    } else if(props.timeToGo === "Winter") {
        styles = {
            backgroundColor: "grey",
        }
    }
    return (
        <div style={styles}>
        <h1>Place: {props.place}</h1>
        <p>Price: {props.price}</p>
        <p>Departure Season: {props.timeToGo}</p>
        <p>Price Range: {priceRange}</p>
        </div>
    )
}

export default Template;
