import React from "React";

function App() {
    return {
        <div>
            <Time />
            <Buttons />
        </div>
    }
}

export default App;
