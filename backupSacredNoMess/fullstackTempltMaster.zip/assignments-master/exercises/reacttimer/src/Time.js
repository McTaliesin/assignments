import React from "react";

function Time() {
    return (
        <div>
            <h1></h1>
        </div>
    )
}

export default Time;
