document.add.addEventListener("submit", function(e){
    e.preventDefault();
    var firstAdd = document.add.first.value;
    var secondAdd = document.add.second.value;
    var result = parseInt(firstAdd) + parseInt(secondAdd);
    document.getElementById("add-result").textContent = result;
});

document.subtract.addEventListener("submit", function(e){
    e.preventDefault();
    var firstSub = document.subtract.first.value;
    var secondSub = document.subtract.second.value;
    var result = parseInt(firstSub) - parseInt(secondSub);
    document.getElementById("sub-result").textContent = result;
});

document.multiply.addEventListener("submit", function(e){
    e.preventDefault();
    var firstMul = document.multiply.first.value;
    var secondMul = document.multiply.second.value;
    var result = parseInt(firstMul) * parseInt(secondMul);
    document.getElementById("mul-result").textContent = result;
});
