This file contains code that creates a simple calculator.
