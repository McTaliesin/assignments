function myFunction() {
	var result = "Hello world!";
	console.log(result);
}

myFunction()
