This file contains code practicing creating directories in the terminal, as well as creating and shifting content around within said files.
