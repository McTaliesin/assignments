import React, {Component} from "react";
import People from "./People";
import axios from "axios";

class List extends Component {
    constructor(){
        super()
        this.state = {
            people: []
        }
    }

    componentDidMount(){
        axios.get("http://api.vschool.io:6543/hitlist.json").then((response) => {
            this.setState({
                people: response.data
            });
        })
    }

    render(){
        let mappedPeople = this.state.people.map((individuals) => {
            return <People name={individuals.name} image={individuals.image} />
        })
        return (
            <div>{mappedPeople}</div>
        )
    }
}

export default List;
