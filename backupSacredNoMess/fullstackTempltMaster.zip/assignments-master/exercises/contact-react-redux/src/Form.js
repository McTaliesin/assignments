import React, {Component} from "react";
import {addContact} from "./redux";
import {connect} from "react-redux";

class Form extends Component {
    constructor(){
        super();
        this.state = {
            name: "",
            age: ""

        }
        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
    }

    handleChange(e){
        this.setState({[e.target.name]: e.target.value})
    }

    handleSubmit(e){
        e.preventDefault();
        this.props.addContact(this.state);
        this.setState({
            name: "",
            age: ""
        })
    }

    render() {
        return (
            <form onSubmit={this.handleSubmit}>
                <input type="text" name="name" value={this.state.name} onChange={this.handleChange} placeholder="name" />
                <input type="text" name="age" value={this.state.age} onChange={this.handleChange} placeholder="age"/>
                <button>Submit</button>
            </form>
        )
    }
}

export default connect(null, {addContact})(Form);
