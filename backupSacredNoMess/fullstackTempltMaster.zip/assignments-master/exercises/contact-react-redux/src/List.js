import React from "react";
import {connect} from "react-redux";

function List(props) {
    console.log(props.contactList);

    const mappedNames = props.contactList.map(newContact => {
        return (
            <div>
            Name: {newContact.name} <br />
            Age: {newContact.age}
            </div>
        )
    })

    return (
        <h2>{mappedNames}</h2>
    )
}


export default connect(state => state)(List);
