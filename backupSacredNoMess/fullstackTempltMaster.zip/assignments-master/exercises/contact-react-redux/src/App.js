import React from "react";
import Form from "./Form";
import List from "./List";

function App() {
    return (
        <div>
            <Form />
            <List />
        </div>
    )
}

export default App;
