import React, {Component} from "react";

class App extends Component {
    constructor(){
        super()
        this.state = {
            item: ""
        }
        this.list = [];
        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
    }

    handleChange(e){
        this.setState({item: e.target.value});
    }

    handleSubmit(e){
        e.preventDefault();
        this.setState({
            item: ""
        });
        this.list.push(this.state.item);
    }

    render(){
        return (
                <form onSubmit={this.handleSubmit}>
                <h1>Moms Shopping List</h1>
                Enter An Item:
                    <input
                        onChange={this.handleChange}
                        value={this.state.item}
                        name="name"
                    />
                    <ol>
                        {this.list.map(obj => <li>{obj}</li>)}
                    </ol>
                <button>Submit</button>
                </form>
        )
    }
}

export default App;
