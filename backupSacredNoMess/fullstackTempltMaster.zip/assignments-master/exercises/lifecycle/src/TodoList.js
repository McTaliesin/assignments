import React, {Component} from "react";
import axios from "axios";

class TodoList extends Component {
    constructor(){
        super();
        this.state={
            people: []
        }

    }

    componentDidMount(){
        console.log("Hey Jude");
        axios.get("https://swapi.co/api/people/").then(response=>{
            this.setstate({people: response.data.results})

        })
    }


    render(){
        const mappedPeople = this.state.people.map(person=>{
            return <div>{person.name}</div>
        })
        return <div>{mappedPeople}</div>
    }
}

export default TodoList;
