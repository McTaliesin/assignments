Instructions for this assignment can be found at:

https://coursework.vschool.io/escape-room/
