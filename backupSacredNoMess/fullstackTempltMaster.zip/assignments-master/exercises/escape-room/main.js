var readline = require("readline-sync");
var name = readline.question("What is your name? ");
var options = ["Put hand in hole", "Find the key", "Open the door"];
var hasKey = false;

console.log("Hello " + name + "! Let's play a game.");

function select() {
    var choice = readline.keyInSelect(options, "You must escape the room.  Which option do you choose?");
    if (choice === 0) {
        console.log("You die!  Game over.")
    } else if (choice === 1) {
        console.log("You found the key!")
        hasKey = true;
        choice = "";
        select();
    } else if ((choice === 2) && (hasKey === true)) {
        console.log("You escape!");
    } else if ((choice === 2) && (hasKey === false)) {
        console.log("You do not have they key.  You cannot escape.")
        select();
    }
}

select();
