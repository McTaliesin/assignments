import React from "react";

function About() {
    return (
        <h2>this is about</h2>
    )
}

export default About;
