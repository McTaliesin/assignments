import React from "react";
import {Link} from "react-router-dom";

function Header() {
    return (
        <div>
        <Link to="/">Home</Link>
        <Link to="/about">About</Link>
        <Link to="Contact">Contact</Link>
        <Link to="Services">Services</Link>
        </div>
    )
}

export default Header;
