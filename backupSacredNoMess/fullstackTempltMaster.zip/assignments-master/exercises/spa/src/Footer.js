import React from "react";

function Footer() {
    return (
        <h1>footer</h1>
    )
}

export default Footer;
