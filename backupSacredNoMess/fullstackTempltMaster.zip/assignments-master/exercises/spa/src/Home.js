import React from "react";

function Home() {
    return (
        <h1>hello</h1>
    )
}

export default Home;
