import React from "react";
import Friend from "./Friend";

function Pet(props) {
    return (
        <div>
            <p>Pet Name: {props.name}</p>
            <p>Pet Breed: {props.breed}</p>
        </div>
    )
}

export default Pet;
