import React, {Component} from "react";
import FriendList from "./FriendList";


class App extends Component {
    render(){
    return (
        <div>
            <FriendList />
        </div>
    )
    }
}


export default App;
