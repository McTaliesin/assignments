import React from "react";
import FriendList from "./FriendList";
import Pet from "./Pet";

function Friend(props) {
    const mappedPets = props.pets.map(function(pet) {
        return <Pet name={pet.name} breed={pet.breed} />
    })
    return (
        <div>
            <h1>Name: {props.name}</h1>
            <p>Age: {props.age}</p>
            <div>{mappedPets}</div>
        </div>
    )
}

export default Friend;
