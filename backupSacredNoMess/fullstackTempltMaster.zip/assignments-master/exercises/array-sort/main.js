var numbers = [1, 3, 5, 2, 90, 20];

var strings = ["dog", "wolf", "by", "family", "eaten"];

var objects = ([
    {
        name: "Quiet Samurai",
        age: 22
    },
    {
        name: "Arrogant Ambassador",
        age: 100
    },
    {
        name: "Misunderstood Observer",
        age: 2
    },
    {
        name: "Unlucky Swami",
        age: 77
    }
])

// var ascending = numbers.sort(function(a, b){
//     return a - b;
// })
// console.log(ascending);

// var descending = numbers.sort(function(a, b){
//     return b - a;
// })
// console.log(descending);

// var stringSort = strings.sort(function(a, b){
//     return a.length - b.length;
// })
// console.log(stringSort);
//
// var alphabetically = strings.sort().reverse();
//
// console.log(alphabetically);

var sortedAge = objects.sort(function(a, b){
    return a.age- b.age;
})

console.log(sortedAge);
