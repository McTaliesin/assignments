var people = ["Jon", "Jacob", "Jingle", "Heimer", "Schmidt"];
var alphabet = "abcdefghijklmnopqrstuvwxyz";

for (i = 0; i < people.length; i++) {
    console.log(people[i]);
    for (j = 0; j < alphabet.length; j++) {
        var individLetter = alphabet[j]
        console.log(alphabet[j]);
    }
}
