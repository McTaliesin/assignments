This file contains code to build a Javascript based calculator operating with Node.

https://coursework.vschool.io/javascript-calculator/
