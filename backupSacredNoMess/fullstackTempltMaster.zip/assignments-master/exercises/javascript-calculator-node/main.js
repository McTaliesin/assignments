var readLine = require("readline-sync");

var num1 = readLine.question("What is your first number? ");
var num2 = readLine.question("What is your second number? ");
var operation = ["Multiply", "Divide", "Add", "Subtract"];

function performMath(num1, num2) {
    var selected = readLine.keyInSelect(operation, "Which math function do you want to perform? ");
    if (operation[selected] === "Multiply") {
        console.log(num1 * num2);
    } else if (operation[selected] === "Divide") {
        console.log(num1 / num2);
    } else if (operation[selected] === "Add") {
        console.log(parseInt(num1) + parseInt(num2));
    } else if (operation[selected] === "Subtract") {
        console.log(parseInt(num1) - parseInt(num2));
    } else {
        console.log("Your program has been ended.");
    }
}

performMath(num1, num2);
