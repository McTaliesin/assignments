var exports = module.exports = {};

exports.tutorial = function() {
    console.log("Guru99 Tutorial");
}
