var localTutor = require("./NodeTutorial.js");

localTutor.NodeTutorial();
localTutor.NodeTutorial.pTutor();
