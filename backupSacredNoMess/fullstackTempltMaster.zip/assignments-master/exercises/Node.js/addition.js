var exports = module.exports = {};

exports.AddNumber = function(a, b) {
    return a + b;
};
