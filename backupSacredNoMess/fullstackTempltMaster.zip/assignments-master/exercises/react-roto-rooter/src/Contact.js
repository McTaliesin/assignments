import React from "react";

function Contact() {
    return (
        <h2>This is the Contact page</h2>
    )
}

export default Contact;
