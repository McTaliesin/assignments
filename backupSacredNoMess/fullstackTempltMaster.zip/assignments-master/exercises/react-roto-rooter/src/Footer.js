import React from "react";

function Footer() {
    return (
        <h1>This is a footer</h1>
    )
}

export default Footer;
