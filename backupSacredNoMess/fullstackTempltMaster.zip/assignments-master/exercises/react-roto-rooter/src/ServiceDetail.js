import React from "react";
import data from "./data.json";

function ServiceDetail(props) {
    const service = data.find(item => {
        return item.name.toLowerCase().split(" ").join("-") === props.match.params.serviceId;
    })
    return (
        <div>
        <h1>{service.name}</h1>
        <h3>Price: {service.price}/hr.</h3>
        </div>
    )
}

export default ServiceDetail;
