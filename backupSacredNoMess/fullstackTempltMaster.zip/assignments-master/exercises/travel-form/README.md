This file contains HTML and Javascript code that makes a pseudo client website for a travel company.
