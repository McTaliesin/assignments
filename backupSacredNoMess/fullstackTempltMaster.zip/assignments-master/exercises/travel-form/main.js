document.travelInfo.addEventListener("submit", function(e){
    e.preventDefault();
    var first = document.travelInfo.firstName.value;
    var last = document.travelInfo.lastName.value;
    var age = document.travelInfo.age.value;
    var gender = document.travelInfo.gender.value;
    var destination = document.travelInfo.destination.value;
    var checkeddietaryRestrictions = []
    var checkedBoxes = document.travelInfo.dr;
    for (var i = 0; i < checkedBoxes.length; i++) {
        if (checkedBoxes[i].checked) {
            checkeddietaryRestrictions.push(checkedBoxes[i].value);
        }
    }
    alert(
        "First Name: " + first + "\n" +
        "Last Name: " + last + "\n" +
        "Age: " + age + "\n" +
        "Gender: " + gender + "\n" +
        "Destination: " + destination + "\n" +
        "Dietary Restrictions: " + checkeddietaryRestrictions.join(", ")+ "\n"
    )
});
