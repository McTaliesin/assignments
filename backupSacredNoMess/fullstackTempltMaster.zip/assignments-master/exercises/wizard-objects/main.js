function Wizard (name, hairColor, beardLength, wandType) {
    this.name = name;
    this.hairColor = hairColor;
    this.beardLength = beardLength;
    this.wandType = wandType;
    this.method1 = "The hair is " + hairColor + ".";
    this.method2 = "The wand is " + wandType + ".";
}

var wizards = [];

var harry = new Wizard("harry", "black", "clean shaven", "cedar");
var ron = new Wizard("ron", "red", "stubble", "oak");
var hermoine = new Wizard("hermoine", "brown", "none", "birch");
var fred = new Wizard("fred", "red", "clean shaven", "pine");
var david = new Wizard("david", "red", "stubble", "ivory");


wizards.push(harry, ron, hermoine, fred, david);
console.log(wizards);
