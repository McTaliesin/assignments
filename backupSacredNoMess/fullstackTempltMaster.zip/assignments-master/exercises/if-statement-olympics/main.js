// Preliminary 1
if (5 > 3) {
    console.log("is greater than");
}

// Preliminary 2
var cat ="cat";

if (cat.length === 3) {
    console.log("is the length");
}

// Preliminary 3
var cat = "cat";
var dog = "dog";
if (cat === dog) {
    console.log("they are the same");
  } else {
    console.log("not the same");
}

// Bronze Medal
var person = {
    name: "Bobby",
    age: 12
}

if (person.name[0] = "B") {
    console.log(person.name + " is allowed to go to the movie.");
  } else {
    console.log(person.name + " is NOT allowed to go to the movie.");
}

// Silver Medal
if ((3 * 4) > 10 && (5 + 10) > 10) {
    console.log("true");
  } else {
    console.log("false");
}

// Gold Medal
