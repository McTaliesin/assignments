This file contains code practicing if statements in Javascript.
