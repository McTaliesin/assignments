var string = "bookkeeper larry";
var usedOnce = "";

function eliminateDuplicates(string) {
    for (i = 0; i < string.length; i++) {
        if (string.lastIndexOf(string[i]) == string.indexOf(string[i])) {
            usedOnce = usedOnce + string[i];
            console.log(usedOnce);
        }
    }
}

console.log(eliminateDuplicates("bookkeeper larry"));


// function find_unique_characters(str) {
//   var unique = '';
//   for (var i = 0; i < str.length; i++) {
//     if (str.lastIndexOf(str[i]) == str.indexOf(str[i])) {
//       unique += str[i];
//     }
//   }
//   return unique;
// }
//
// console.log(find_unique_characters('baraban'));
// console.log(find_unique_characters('anaconda'));
