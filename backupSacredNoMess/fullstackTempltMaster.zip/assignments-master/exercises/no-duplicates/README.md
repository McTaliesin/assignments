This file contains code that eliminates duplicates from a string and compiles the repeating characters into a separate variable.
