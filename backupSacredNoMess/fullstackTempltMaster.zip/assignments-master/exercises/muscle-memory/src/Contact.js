import React from "react";

function Contact() {
    return (
        <div className="contact">
            <h1>This is my Contact</h1>
        </div>

    )
}

export default Contact;
