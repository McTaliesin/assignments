import React from "react";

function About() {
    return (
        <div className="about">
            <h1>This is my About</h1>
        </div>
    )
}

export default About;
