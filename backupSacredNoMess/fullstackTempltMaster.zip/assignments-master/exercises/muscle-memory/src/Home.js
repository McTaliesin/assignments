import React, {Component} from "react";
import axios from "axios";
import APIoutput from "./APIoutput";

class Home extends Component {
    constructor() {
        super();
        this.state = {
            todos: [],
            newTitle: "",
            newDis: ""
        }
        this.handleTitleChange = this.handleTitleChange.bind(this);
        this.handleDisChange = this.handleDisChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
    }

    componentDidMount() {
        axios.get("https://api.vschool.io/ericjones/todo/").then((response) => {
            console.log(response);
            this.setState(() => {
                return {
                    todos: response.data
                }
            })
        })
    }

    handleTitleChange(event) {
        this.setState({
            newTitle: event.target.value
        })
    }

    handleDisChange(event) {
        this.setState({
            newDis: event.target.value
        })
    }

    handleSubmit(event) {
        event.preventDefault();
        this.setState({
            newTitle: "",
            newDis: ""
        })
        axios.post("https://api.vschool.io/ericjones/todo/", {
            "title": this.state.newTitle,
            "description": this.state.newDis
        }).then(response => {
            console.log(response);
        }).catch(error => {
            console.log(error);
        })
    }

    render() {
        let mappedTodos = this.state.todos.map((todo) => {
            return <APIoutput key={todo._id + todo.title} id={todo._id} title={todo.title} description={todo.description} />
        })

        return (
            <div className="home">
                {mappedTodos}
                <form onSubmit={this.handleSubmit}>
                    <input type="text" id="newTitle" value={this.state.newTitle} onChange={this.handleTitleChange}/> <br />
                    <input type="text" id="newDis" value={this.state.newDis} onChange={this.handleDisChange}/> <br />
                    <input type="submit" value="Submit" />
                </form>
            </div>
        )
    }
}

export default Home;
