import React, {Component} from "react";
import axios from "axios";

const APIurl = "https://api.vschool.io/ericjones/todo/";

class EditButton extends Component {
    constructor() {
        super();
        this.state = {
            editTitle: "",
            editDis: "",
            isEdit: false
        }
        this.handleEditSubmit = this.handleEditSubmit.bind(this);
        this.handleETChange = this.handleETChange.bind(this);
        this.handleEDChange = this.handleEDChange.bind(this);
        this.startEdit = this.startEdit.bind(this);
    }

    handleEditSubmit(event) {
        event.preventDefault();
        this.setState({
            editTitle: "",
            editDis: "",
            isEdit: false
        })
        axios.put(APIurl + this.props.editId, {
            "title": this.state.editTitle,
            "description": this.state.editDis
        }).then(response => {
            console.log(response);
        }).catch(error => {
            console.log(error);
        })
    }

    handleETChange(event) {
        this.setState({
            editTitle: event.target.value
        })
    }

    handleEDChange(event) {
        this.setState({
            editDis: event.target.value
        })
    }

    startEdit() {
        this.setState({
            isEdit: true
        })
    }

    render() {
        return (
            this.state.isEdit ?
            <form onSubmit={this.handleEditSubmit}>
                <input type="text" name="editTitle" value={this.state.editTitle} onChange={this.handleETChange}/>
                <input type="text" name="editDis" value={this.state.editDis} onChange={this.handleEDChange}/>
                <input type="submit" value="Update" />
            </form>
            :
            <button onClick={this.startEdit}>Edit</button>

        )
    }
}

export default EditButton;
