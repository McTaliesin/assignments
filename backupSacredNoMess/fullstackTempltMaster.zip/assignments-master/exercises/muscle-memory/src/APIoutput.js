import React from "react";
import EditButton from "./EditButton";
import DeleteButton from "./DeleteButton";

function APIoutput(props) {
    return (
        <div className="outputAPI">
            <h5>{props.title}</h5>
            <p>{props.description}</p>
            <p>{props.id}</p>
            <EditButton editId={props.id} />
            <DeleteButton deleteId={props.id} />
        </div>
    )
}

export default APIoutput;
