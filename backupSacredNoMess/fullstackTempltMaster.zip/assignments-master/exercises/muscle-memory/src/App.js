import React from "react";
import { Switch, Route } from "react-router-dom";
import Header from "./Header";
import Footer from "./Footer";
import About from "./About"
import Contact from "./Contact";
import Home from "./Home";

function App() {
    return (
        <div className="body">
            <Header/>
            <Switch>
                <Route exact path="/" component={Home}/>
                <Route exact path="/about" component={About}/>
                <Route exact path="/contact" component={Contact}/>
            </Switch>
            <Footer/>
        </div>
    )
}

export default App;
