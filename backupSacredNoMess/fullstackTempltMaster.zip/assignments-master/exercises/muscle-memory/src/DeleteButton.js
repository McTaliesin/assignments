import React, {Component} from "react";
import axios from "axios";

const APIurl = "https://api.vschool.io/ericjones/todo/";


class DeleteButton extends Component {
    constructor() {
        super();
        this.handleDelete = this.handleDelete.bind(this);
    }

    handleDelete(event) {
        event.preventDefault();
        this.setState({
            "_id": ""
        })
        axios.delete(APIurl + this.props.deleteId).then(response => {
            console.log(response);
        }).catch(error => {
            console.log(error);
        })
    }

    render() {
        return (
            <button onClick={this.handleDelete}>Delete</button>
        )
    }
}

export default DeleteButton;
