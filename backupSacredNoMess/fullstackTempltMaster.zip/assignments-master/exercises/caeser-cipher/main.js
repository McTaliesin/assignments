var readLine = require("readLine-sync");
var alphabet = "abcdefghijklmnopqrstuvwxyz";

var inputPhrase = readLine.question("Enter your input phrase now: ").toLowerCase();
var inputNum = readLine.question("How many letters should we shift your phrase: ")

while(isNaN(inputNum)){
    var inputNum = parseInt(readLine.question("You were supposed to enter a number.  Enter one now: "));
}

function encode(phrase, shiftNumber) {
    var newString = "";
    for (i=0; i<phrase.length; i++) {
        if(alphabet.includes(phrase[i])){
            var indexInAlphabet = alphabet.indexOf(phrase[i]);
            newString += alphabet[(indexInAlphabet + shiftNumber) % 26];

        } else {
            newString += phrase[i];
        }
    }
    return newString;
}

console.log(encode(inputPhrase, inputNum));
