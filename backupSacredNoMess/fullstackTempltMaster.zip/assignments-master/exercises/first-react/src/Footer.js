import React from "react";

function Footer() {
    return (
        <ul>
        <li>How</li>
        <li>Ye</li>
        <li>Doin</li>
        </ul>
    )
};

export default Footer;
