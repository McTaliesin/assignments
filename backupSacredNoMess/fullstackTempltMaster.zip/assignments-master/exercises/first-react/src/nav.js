import React from "react";

function Nav() {
    return (
        <ul>
            <li>Home</li>
            <li>About</li>
            <li>Contact</li>
        </ul>
    )
};

export default Nav;
