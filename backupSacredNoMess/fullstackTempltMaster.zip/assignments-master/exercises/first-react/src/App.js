import React from "react";
import Footer from "./Footer"

function App(){
    return (
        <h1>
        Welcome to my app
        <Footer />
        </h1>
    )
}

export default App;
