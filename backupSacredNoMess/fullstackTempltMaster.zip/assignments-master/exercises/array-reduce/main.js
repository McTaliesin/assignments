var numbers = [1, 2, 3];

// var sum = numbers.reduce(function(previous, number) {
//     return previous + number;
// }, 0);
//
// console.log(sum);

// var string = numbers.reduce(function(previous, number) {
//     return previous.concat(number);
// }, "")
// console.log(string);

// var voters = [
//     {name:'Bob' , age: 30, voted: true},
//     {name:'Jake' , age: 32, voted: true},
//     {name:'Kate' , age: 25, voted: false},
//     {name:'Sam' , age: 20, voted: false},
//     {name:'Phil' , age: 21, voted: true},
//     {name:'Ed' , age:55, voted:true},
//     {name:'Tami' , age: 54, voted:true},
//     {name: 'Mary', age: 31, voted: false},
//     {name: 'Becky', age: 43, voted: false},
//     {name: 'Joey', age: 41, voted: true},
//     {name: 'Jeff', age: 30, voted: true},
//     {name: 'Zack', age: 19, voted: false}
// ];
//
// var totalVoted = voters.reduce(function(didVote, voter) {
//     if(voter.voted === true) {
//         didVote.didVote++;
//     } else {
//         didVote.didntVote++;
//     }
//     return didVote;
// }, {didVote: 0, didntVote: 0});
// console.log(totalVoted);


// var wishlist = [
//     { title: "Tesla Model S", price: 90000 },
//     { title: "4 carat diamond ring", price: 45000 },
//     { title: "Fancy hacky Sack", price: 5 },
//     { title: "Gold fidgit spinner", price: 2000 },
//     { title: "A second Tesla Model S", price: 90000 }
// ];
//
// var blowCash = wishlist.reduce(function(total, nextItem) {
//     return nextItem.price + total;
// }, 0)
//
// console.log(blowCash);

// var arrays = [
//     ["1", "2", "3"],
//     [true],
//     [4, 5, 6]
// ];
//
// var mesh = arrays.reduce(function(original, next) {
//     return original.concat(next);
// }, []);
//
// console.log(mesh);

var voters = [
    {name:'Bob' , age: 30, voted: true},
    {name:'Jake' , age: 32, voted: true},
    {name:'Kate' , age: 25, voted: false},
    {name:'Sam' , age: 20, voted: false},
    {name:'Phil' , age: 21, voted: true},
    {name:'Ed' , age:55, voted:true},
    {name:'Tami' , age: 54, voted:true},
    {name: 'Mary', age: 31, voted: false},
    {name: 'Becky', age: 43, voted: false},
    {name: 'Joey', age: 41, voted: true},
    {name: 'Jeff', age: 30, voted: true},
    {name: 'Zack', age: 19, voted: false}
];

var stats = voters.reduce(function(data, voter) {
    if (voter.age >= 18 && voter.age <= 25) {
        data.youth++;
    }
    if (voter.age >= 26 && voter.age <= 35) {
        data.mids++;
    }
    if (voter.age >= 36 && voter.age <= 55) {
        data.olds++;
    }
    if ((voter.age >= 18 && voter.age <= 25) && (voter.voted === true)) {
        data.youngVotes++;
    }
    if ((voter.age >= 26 && voter.age <= 35) && (voter.voted === true)) {
        data.midVotes++;
    }
    if ((voter.age >= 36 && voter.age <= 55) && (voter.voted === true)) {
        data.oldVotes++;
    }
    return data;
}, {youngVotes: 0, youth: 0, midVotes: 0, mids: 0, oldVotes: 0, olds: 0});

console.log(stats);
