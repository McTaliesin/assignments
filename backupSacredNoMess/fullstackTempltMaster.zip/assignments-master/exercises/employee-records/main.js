var employees = [];

function Employee (name, title, salary, status) {
    this.name = name;
    this.title = title;
    this.salary = salary;
    this.status = status || "Full-time";
    printEmployeeForm = console.log(this.name + ", " + this.title + ", " + this.salary + ", " + this.status);
}

var employee1 = new Employee("Alex Orr", "Owner", "$1,000,000");
var employee2 = new Employee("Emily Miller", "Co Owner", "$1,000,000");
var employee3 = new Employee("Gay Orr", "Counsel", "$1,000,000", "Part Time");

employees.push(employee1, employee2, employee3);

console.log(employees);
