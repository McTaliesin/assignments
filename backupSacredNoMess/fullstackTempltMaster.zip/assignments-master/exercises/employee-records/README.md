Instructions for this exercise are available at:

https://coursework.vschool.io/employee-records/
