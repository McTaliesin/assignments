This file contains HTML and CSS code that practices building a newspaper.
