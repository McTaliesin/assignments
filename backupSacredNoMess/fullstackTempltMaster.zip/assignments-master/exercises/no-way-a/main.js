var string = "Alex went to Iceland and then Antartica."

lowerString = string.toLowerCase();

// console.log(lowerString);

// arrayString = lowerString.split("");

// console.log(arrayString);

var result = "";

for (i = 0; i < lowerString.length; i++) {
    if (lowerString[i] !== "a") {
        result += lowerString[i];
    }
}

console.log(result);

// console.log(arrayString);

// function converting it all to lowercase
// function that removes all letters (a)
