import React from "react";
import Button from "./Button";

function Press(props){
    return (
    <button onClick={props.handleClick}>{props.text}</button>
    )
}

export default Press;
