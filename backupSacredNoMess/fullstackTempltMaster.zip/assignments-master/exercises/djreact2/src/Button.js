import React from "react";
import Press from "./Press"
import App from "./App";

function Button(props){
    return (
        <div>
            <Press text="B&W" handleClick={props.handleButtonOne} />
            <Press text="Purple" handleClick={props.handleButtonTwo} />
        </div>
    )
}

export default Button;
