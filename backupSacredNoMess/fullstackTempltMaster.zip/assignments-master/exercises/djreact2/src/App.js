import React, {Component} from "react";
import Grid from "./Grid";
import Button from "./Button";

class App extends Component {
    constructor(){
        super();
        this.state={
            colorGrid: {
                one: "white",
                two: "white",
                three: "white",
                four: "white"
            }
        }
        this.handleButtonOne = this.handleButtonOne.bind(this);
        this.handleButtonTwo = this.handleButtonTwo.bind(this);
    }

    handleButtonOne(){
        this.setState((prevState)=>{
            if (prevState.colorGrid.one === "white") {
            return {
                colorGrid: {
                    one: "black",
                    two: "black",
                    three: "black",
                    four: "black"
                }
            }
            } else {
                return {
                    colorGrid: {
                        one: "white",
                        two: "white",
                        three: "white",
                        four: "white"
                    }
                }
            }
    })
    }

    handleButtonTwo(){
        this.setState({
                colorGrid: {
                    one: "purple",
                    two: "purple",
                    three: "white",
                    four: "white"
                }
        })
    }

    render(){
        return (
            <div>
                <Grid gridColors={this.state.colorGrid} />
                <Button handleButtonOne={this.handleButtonOne}
                        handleButtonTwo={this.handleButtonTwo}
                />
            </div>
        )
    }
}

export default App;
