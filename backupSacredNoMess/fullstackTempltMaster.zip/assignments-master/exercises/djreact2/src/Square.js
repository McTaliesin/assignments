import React from "react";
import Grid from "./Grid";

function Square(props) {
    const styles={
        backgroundColor: props.color,
        height: "100px",
        width: "100px",
        border: "1px solid black"
    }

    return (
        <div style={styles}><h1>hi</h1></div>
    )
}

export default Square;
