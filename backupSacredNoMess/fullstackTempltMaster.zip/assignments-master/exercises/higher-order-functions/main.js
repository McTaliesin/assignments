var cars = [
    {
        make: "Chevrolet",
        model: "Corvette",
        year: 2005
    },
    {
        make: "VW",
        model: "Jetta",
        year: 2001
    },
    {
        make: "Land Rover",
        model: "LR3",
        year: 2005
    }
]

// var outcome = cars.forEach(function(car){
//     console.log(car + " goes vroom");
// })

// var toUpperCase = cars.map(function(car){
//     console.log(car.toUpperCase());
// })

// var year = cars.filter(function(car){
//     if (car.year > 2002) {
//         console.log(car);
//     }
// })

// var find = cars.find(function(car){
//     if (car.model === "Jetta") {
//         console.log(car);
//     }
// })

// var some = cars.some(function(car){
//     return car.year > 2002;
// })
// console.log(some);

var every = cars.every(function(car){
    return car.model === "Jetta";
})
console.log(every);
